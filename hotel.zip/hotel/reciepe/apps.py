from django.apps import AppConfig


class ReciepeConfig(AppConfig):
    name = 'reciepe'
