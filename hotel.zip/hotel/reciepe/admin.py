from django.contrib import admin
from reciepe.models import Reciepe

admin.site.register(Reciepe)


